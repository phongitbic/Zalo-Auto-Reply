import React from "react";
import { createRoot } from "react-dom/client";
import { Capacitor, registerPlugin } from "@capacitor/core";
import { LocalNotifications } from "@capacitor/local-notifications";
import { normalizeServerUrl, validateNativeServerUrl } from "./server-url.js";
import "./styles.css";

const OrderService = registerPlugin("OrderService");
const isNative = Capacitor.isNativePlatform();
const storage = {
  get: (key, fallback = "") => localStorage.getItem(key) ?? fallback,
  set: (key, value) => localStorage.setItem(key, value),
};
const emptyRoute = () => ({
  id: null,
  title: "",
  origin: "",
  destination: "",
  prices: "",
  excludedKeywords: "",
  enabled: true,
});
const formatTime = (value) => value ? new Date(value).toLocaleString("vi-VN") : "--";
const splitListItems = (value) => String(value ?? "")
    .split(/[,;\n]+/)
    .map((item) => item.trim())
    .filter(Boolean);
const countListItems = (value) => new Set(
  splitListItems(value).map((item) => item.toLocaleLowerCase("vi"))
).size;
const routeDisplayTitle = (route) => route.title || `${splitListItems(route.origin)[0] || "Điểm đi"} → ${splitListItems(route.destination)[0] || "Điểm đến"}`;
const modeText = (status) => !status?.enabled
  ? "Đã dừng nhận đơn"
  : status.mode === "priority" ? "Đang nhận cuốc ưu tiên" : "Đang nhận tất cả";

function App() {
  const socketRef = React.useRef(null);
  const nativeListenersRef = React.useRef(null);
  const seenEvents = React.useRef(new Set());
  const shownActiveOrder = React.useRef(null);
  const [serverUrl, setServerUrl] = React.useState(() => storage.get("serverUrl"));
  const [adminToken, setAdminToken] = React.useState(() => isNative ? "" : storage.get("adminToken"));
  const [autoConnectReady, setAutoConnectReady] = React.useState(() => !isNative && Boolean(storage.get("adminToken")));
  const [status, setStatus] = React.useState(null);
  const [qrRevision, setQrRevision] = React.useState("");
  const [connectionState, setConnectionState] = React.useState("disconnected");
  const [page, setPage] = React.useState("dashboard");
  const [notice, setNotice] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  const [savingRouteId, setSavingRouteId] = React.useState(null);
  const [routeSearch, setRouteSearch] = React.useState("");
  const [routeFilter, setRouteFilter] = React.useState("all");
  const [routeDraft, setRouteDraft] = React.useState(null);
  const [notificationSettings, setNotificationSettings] = React.useState(() => {
    const defaults = { sound: true, vibrate: true, speech: false, overlay: true, manualReplyOverlay: false };
    try {
      return { ...defaults, ...(JSON.parse(storage.get("notificationSettings", "")) || {}) };
    } catch {
      return defaults;
    }
  });

  const apiUrl = React.useCallback((endpoint) => `${normalizeServerUrl(serverUrl)}${endpoint}`, [serverUrl]);
  const apiFetch = React.useCallback(async (endpoint, options = {}) => {
    const response = await fetch(apiUrl(endpoint), {
      ...options,
      headers: {
        ...(options.body ? { "content-type": "application/json" } : {}),
        authorization: `Bearer ${adminToken}`,
        ...options.headers,
      },
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) {
      const message = response.status === 401
        ? "Token quản trị không đúng"
        : [result.error || "Máy chủ không phản hồi", result.detail].filter(Boolean).join(" ");
      const error = new Error(message);
      error.payload = result;
      throw error;
    }
    return result;
  }, [adminToken, apiUrl]);

  const notifyOrder = React.useCallback(async (order) => {
    const dedupeKey = order.eventId || order.messageId;
    if (!dedupeKey || seenEvents.current.has(dedupeKey)) return;
    seenEvents.current.add(dedupeKey);
    if (!isNative && "Notification" in window && Notification.permission === "granted") {
      new Notification("ĐÃ NHẬN ĐƠN THÀNH CÔNG!", {
        body: `${order.senderName || order.groupName}\n${order.originalContent}`,
      });
    }
  }, []);

  const ensureNativeListeners = React.useCallback(() => {
    if (!isNative) return Promise.resolve([]);
    if (!nativeListenersRef.current) {
      nativeListenersRef.current = Promise.all([
        OrderService.addListener("connectionState", (event) => {
          const state = ["connected", "disconnected", "error"].includes(event.state) ? event.state : "error";
          setConnectionState(state);
          if (state === "connected") setNotice("Đã kết nối và đồng bộ với máy chủ");
          if (state === "error") {
            setNotice(String(event.message || "").includes("Unauthorized")
              ? "Token quản trị không đúng"
              : "Mất kết nối máy chủ");
          }
        }),
        OrderService.addListener("serverStatus", (serverStatus) => setStatus(serverStatus)),
        OrderService.addListener("serverStats", (stats) => {
          setStatus((current) => current ? { ...current, stats } : current);
        }),
        OrderService.addListener("serverRedis", (redis) => {
          setStatus((current) => current ? { ...current, redis } : current);
        }),
        OrderService.addListener("zaloQr", (event) => {
          setQrRevision(event?.updatedAt || String(Date.now()));
        }),
      ]);
    }
    return nativeListenersRef.current;
  }, []);

  const connect = React.useCallback(async ({ quiet = false } = {}) => {
    const baseUrl = normalizeServerUrl(serverUrl);
    const serverUrlError = isNative ? validateNativeServerUrl(serverUrl) : "";
    if (serverUrlError) {
      if (!quiet) setNotice(serverUrlError);
      return;
    }
    if (!adminToken.trim()) {
      if (!quiet) setNotice("Hãy nhập token quản trị");
      return;
    }
    setConnectionState("connecting");
    try {
      const bootstrap = await apiFetch("/api/bootstrap");
      setStatus(bootstrap.status);
      storage.set("serverUrl", baseUrl);
      if (isNative) localStorage.removeItem("adminToken");
      else storage.set("adminToken", adminToken);
      socketRef.current?.disconnect();
      socketRef.current = null;
      if (isNative) {
        await ensureNativeListeners();
        const permission = await LocalNotifications.checkPermissions();
        if (permission.display !== "granted") await LocalNotifications.requestPermissions();
        await OrderService.start({ serverUrl: baseUrl, token: adminToken, settings: notificationSettings });
      } else {
        const { io } = await import("socket.io-client");
        const socket = io(baseUrl || undefined, {
          auth: { token: adminToken },
          transports: ["websocket"],
          reconnection: true,
          reconnectionDelay: 1000,
          reconnectionDelayMax: 30000,
          timeout: 10000,
        });
        socketRef.current = socket;
        socket.on("connect", () => {
          setConnectionState("connected");
          if (!quiet) setNotice("Đã kết nối và đồng bộ với máy chủ");
        });
        socket.on("disconnect", () => setConnectionState("disconnected"));
        socket.on("connect_error", (error) => {
          setConnectionState("error");
          setNotice(error.message === "Unauthorized" ? "Token quản trị không đúng" : "Mất kết nối Zcar");
        });
        socket.on("status", setStatus);
        socket.on("qr", (event) => setQrRevision(event?.updatedAt || String(Date.now())));
        socket.on("stats", (stats) => setStatus((current) => current ? { ...current, stats } : current));
        socket.on("redis", (redis) => setStatus((current) => current ? { ...current, redis } : current));
        socket.on("ORDER_ACCEPTED", (order) => {
          void notifyOrder(order);
        });
        if ("Notification" in window && Notification.permission === "default") {
          await Notification.requestPermission();
        }
      }
    } catch (error) {
      setConnectionState("error");
      if (!quiet) setNotice(error.message);
    }
  }, [adminToken, apiFetch, ensureNativeListeners, notificationSettings, notifyOrder, serverUrl]);

  React.useEffect(() => {
    let cancelled = false;
    if (isNative) {
      localStorage.removeItem("adminToken");
      void OrderService.getConnection().then((saved) => {
        if (cancelled || !saved?.token || !saved?.serverUrl) return;
        setServerUrl(saved.serverUrl);
        setAdminToken(saved.token);
        setAutoConnectReady(true);
      }).catch(() => {});
    }
    return () => { cancelled = true; };
  }, []);
  React.useEffect(() => {
    if (!autoConnectReady) return;
    setAutoConnectReady(false);
    void connect({ quiet: true });
  }, [autoConnectReady, connect]);
  React.useEffect(() => () => {
    socketRef.current?.disconnect();
    const nativeListeners = nativeListenersRef.current;
    nativeListenersRef.current = null;
    if (nativeListeners) {
      void nativeListeners.then((handles) => Promise.all(handles.map((handle) => handle.remove()))).catch(() => {});
    }
  }, []);
  React.useEffect(() => {
    storage.set("notificationSettings", JSON.stringify(notificationSettings));
    if (isNative) void OrderService.updateSettings({ settings: notificationSettings }).catch(() => {});
  }, [notificationSettings]);
  React.useEffect(() => {
    const eventId = status?.activeOrder?.eventId;
    if (!eventId || shownActiveOrder.current === eventId) return;
    shownActiveOrder.current = eventId;
    setPage("orders");
  }, [status?.activeOrder?.eventId]);

  const showSaved = (result, successText) => {
    setStatus(result);
    setNotice(result.save?.pending
      ? `${successText}. Redis đang mất kết nối; máy chủ sẽ tự đồng bộ lại.`
      : `${successText} và Redis đã xác nhận lưu.`);
  };

  async function control(action, mode = status?.mode || "all") {
    setBusy(true);
    try {
      const result = await apiFetch("/api/bot/control", {
        method: "POST",
        body: JSON.stringify({ action, mode }),
      });
      showSaved(result, action === "start" ? "Máy chủ đã bắt đầu nhận đơn" : "Máy chủ đã dừng nhận đơn");
    } catch (error) {
      setNotice(error.message);
    } finally {
      setBusy(false);
    }
  }

  async function completeActiveOrder() {
    setBusy(true);
    try {
      const result = await apiFetch("/api/orders/current/complete", { method: "POST" });
      showSaved(result, "Đã xử lý đơn và tự động bật nhận đơn");
      setPage("dashboard");
    } catch (error) {
      setNotice(error.message);
    } finally {
      setBusy(false);
    }
  }

  async function logoutZalo() {
    if (!window.confirm("Đăng xuất tài khoản Zalo khỏi Zcar và tạo mã QR đăng nhập mới?")) return;
    setBusy(true);
    try {
      const result = await apiFetch("/api/zalo/logout", { method: "POST" });
      setStatus(result.status);
      setQrRevision(String(Date.now()));
      setNotice("Đã đăng xuất Zalo khỏi Zcar. Đang tạo mã QR đăng nhập mới.");
    } catch (error) {
      setNotice(error.message);
    } finally {
      setBusy(false);
    }
  }

  async function setOverlayEnabled(enabled) {
    setNotificationSettings((value) => ({ ...value, overlay: enabled }));
    if (!isNative) return;
    try {
      const state = await OrderService.setOverlayEnabled({ enabled });
      if (enabled && !state.granted) {
        setNotice("Hãy cho phép Zcar hiển thị trên ứng dụng khác, sau đó quay lại ứng dụng");
      }
    } catch (error) {
      setNotice(error.message);
    }
  }

  async function setManualReplyEnabled(enabled) {
    setNotificationSettings((value) => ({ ...value, manualReplyOverlay: enabled }));
    if (!isNative) return;
    try {
      const state = await OrderService.setManualReplyEnabled({ enabled });
      if (enabled && !state.overlayGranted) {
        setNotice("Hãy cho phép Zcar hiển thị trên ứng dụng khác, sau đó quay lại ứng dụng");
      } else if (enabled && !state.accessibilityGranted) {
        setNotice("Trong phần Trợ năng, hãy bật dịch vụ Zcar - Nhận tay");
      }
    } catch (error) {
      setNotice(error.message);
    }
  }

  async function saveRoute() {
    setBusy(true);
    try {
      const body = {
        title: routeDraft.title,
        origin: routeDraft.origin,
        destination: routeDraft.destination,
        prices: routeDraft.prices.split(/[,;\n]+/).map((item) => item.trim()).filter(Boolean),
        excludedKeywords: routeDraft.excludedKeywords.split(/[,;\n]+/).map((item) => item.trim()).filter(Boolean),
        enabled: routeDraft.enabled,
      };
      const endpoint = routeDraft.id
        ? `/api/settings/priority-routes/${routeDraft.id}`
        : "/api/settings/priority-routes";
      const result = await apiFetch(endpoint, {
        method: routeDraft.id ? "PATCH" : "POST",
        body: JSON.stringify(body),
      });
      setRouteDraft(null);
      showSaved(result, routeDraft.id ? "Đã cập nhật tuyến" : "Đã thêm tuyến");
    } catch (error) {
      setNotice(error.message);
    } finally {
      setBusy(false);
    }
  }

  async function updateRoute(route, change) {
    setSavingRouteId(route.id);
    try {
      const result = await apiFetch(`/api/settings/priority-routes/${route.id}`, {
        method: "PATCH",
        body: JSON.stringify(change),
      });
      showSaved(result, "Đã cập nhật tuyến");
    } catch (error) {
      setNotice(`Lưu thất bại: ${error.message}`);
    } finally {
      setSavingRouteId(null);
    }
  }

  async function deleteRoute(route) {
    if (!window.confirm(`Xóa tuyến ${routeDisplayTitle(route)}?`)) return;
    setSavingRouteId(route.id);
    try {
      const result = await apiFetch(`/api/settings/priority-routes/${route.id}`, { method: "DELETE" });
      showSaved(result, "Đã xóa tuyến");
    } catch (error) {
      setNotice(error.message);
    } finally {
      setSavingRouteId(null);
    }
  }

  async function toggleAll(enabled) {
    setSavingRouteId("all");
    try {
      const result = await apiFetch("/api/settings/priority-routes", {
        method: "PATCH",
        body: JSON.stringify({ enabled }),
      });
      showSaved(result, enabled ? "Đã bật tất cả tuyến" : "Đã tắt tất cả tuyến");
    } catch (error) {
      setNotice(error.message);
    } finally {
      setSavingRouteId(null);
    }
  }

  const routes = status?.priorityRoutes || [];
  const query = routeSearch.trim().toLocaleLowerCase("vi");
  const visibleRoutes = routes.filter((route) => {
    const matchesSearch = !query || `${route.title || ""} ${route.origin} ${route.destination} ${(route.prices || []).join(" ")} ${(route.excludedKeywords || []).join(" ")}`.toLocaleLowerCase("vi").includes(query);
    const matchesFilter = routeFilter === "all" || (routeFilter === "enabled" ? route.enabled : !route.enabled);
    return matchesSearch && matchesFilter;
  });

  if (!status) return <ConnectScreen {...{ serverUrl, setServerUrl, adminToken, setAdminToken, connectionState, connect, notice }} />;

  return (
    <main>
      <header className="app-header">
        <div>
          <span className={`connection ${connectionState}`}><i />{connectionState === "connected" ? "Máy chủ đã kết nối" : connectionState === "connecting" ? "Đang kết nối máy chủ" : "Mất kết nối máy chủ"}</span>
          <h1>Điều khiển nhận đơn</h1>
          <p>Zalo: <strong>{status.status}</strong> · {modeText(status)}</p>
        </div>
        <button className="icon-button" aria-label="Cài đặt kết nối" onClick={() => setPage("connection")}>⚙</button>
      </header>

      <nav className="nav-tabs" aria-label="Điều hướng">
        <button className={page === "dashboard" ? "active" : ""} onClick={() => setPage("dashboard")}>Tổng quan</button>
        <button className={page === "routes" ? "active" : ""} onClick={() => setPage("routes")}>Cuốc ưu tiên</button>
        <button className={page === "orders" ? "active" : ""} onClick={() => setPage("orders")}>Đơn đã nhận{status.activeOrder ? " •" : ""}</button>
        <button className={page === "settings" ? "active" : ""} onClick={() => setPage("settings")}>Cài đặt</button>
      </nav>

      {page === "dashboard" && <Dashboard {...{ status, busy, control }} />}
      {page === "orders" && <ReceivedOrderPage order={status.activeOrder} busy={busy} onComplete={completeActiveOrder} />}
      {page === "routes" && (
        <RoutesPage
          {...{ routes, visibleRoutes, routeSearch, setRouteSearch, routeFilter, setRouteFilter, savingRouteId }}
          onAdd={() => setRouteDraft(emptyRoute())}
          onEdit={(route) => setRouteDraft({ ...route, prices: (route.prices || []).join(", "), excludedKeywords: (route.excludedKeywords || []).join(", ") })}
          onUpdate={updateRoute}
          onDelete={deleteRoute}
          onToggleAll={toggleAll}
        />
      )}
      {page === "settings" && (
        <>
          <ZaloLogin status={status} apiUrl={apiUrl} token={adminToken} revision={qrRevision} busy={busy} onLogout={logoutZalo} />
          <GroupSelector apiFetch={apiFetch} status={status} onStatus={setStatus} onNotice={setNotice} />
          <section className="settings panel">
            <h2>Thông báo Android</h2>
            {[["sound", "Âm thanh"], ["vibrate", "Rung"], ["speech", "Giọng đọc tiếng Việt"]].map(([key, label]) => (
              <label className="switch-row" key={key}><span>{label}</span><input type="checkbox" checked={notificationSettings[key]} onChange={(event) => setNotificationSettings((value) => ({ ...value, [key]: event.target.checked }))} /></label>
            ))}
            {isNative && <label className="switch-row"><span>Nút điều khiển nổi ngoài ứng dụng</span><input type="checkbox" checked={notificationSettings.overlay} onChange={(event) => void setOverlayEnabled(event.target.checked)} /></label>}
            {isNative && <label className="switch-row"><span>Nút Nhận tay trực tiếp trên Zalo</span><input type="checkbox" checked={notificationSettings.manualReplyOverlay} onChange={(event) => void setManualReplyEnabled(event.target.checked)} /></label>}
            {isNative && <button className="secondary" onClick={() => void OrderService.openAppSettings()}>Mở cài đặt pin ứng dụng</button>}
          </section>
        </>
      )}
      {page === "connection" && (
        <section className="settings panel">
          <h2>Thông tin kết nối</h2>
          <label htmlFor="settings-url">Địa chỉ kết nối</label>
          <input id="settings-url" placeholder="Nhập địa chỉ kết nối" value={serverUrl} onChange={(event) => setServerUrl(event.target.value)} />
          <label htmlFor="settings-token">Token quản trị</label>
          <input id="settings-token" type="password" placeholder="Nhập token quản trị" value={adminToken} onChange={(event) => setAdminToken(event.target.value)} />
          <button className="primary" onClick={() => void connect()}>Lưu và kết nối lại</button>
        </section>
      )}

      {routeDraft && <RouteDialog draft={routeDraft} setDraft={setRouteDraft} busy={busy} onSave={saveRoute} onClose={() => setRouteDraft(null)} />}
      {notice && <button className="notice" onClick={() => setNotice("")}>{notice}</button>}
    </main>
  );
}

function ConnectScreen({ serverUrl, setServerUrl, adminToken, setAdminToken, connectionState, connect, notice }) {
  const [showToken, setShowToken] = React.useState(false);
  return (
    <main className="connect-shell"><section className="connect-card">
      <div className="brand-mark">Zcar</div>
      <div className="connect-heading"><h1>Đăng nhập Zcar</h1><p>Nhập thông tin truy cập để tiếp tục.</p></div>
      <label htmlFor="server-url">Địa chỉ kết nối</label>
      <input id="server-url" inputMode="url" autoCapitalize="none" autoCorrect="off" placeholder="Nhập địa chỉ kết nối" value={serverUrl} onChange={(event) => setServerUrl(event.target.value)} />
      <label htmlFor="admin-token">Token quản trị</label>
      <div className="password-field">
        <input id="admin-token" type={showToken ? "text" : "password"} autoComplete="current-password" placeholder="Nhập token quản trị" value={adminToken} onChange={(event) => setAdminToken(event.target.value)} />
        <button type="button" className="token-toggle" aria-label={showToken ? "Ẩn token quản trị" : "Hiện token quản trị"} onClick={() => setShowToken((value) => !value)}>{showToken ? "Ẩn" : "Hiện"}</button>
      </div>
      <button className="primary large" disabled={connectionState === "connecting"} onClick={() => void connect()}>{connectionState === "connecting" ? "Đang đăng nhập…" : "Đăng nhập"}</button>
      {notice && <div className="notice inline">{notice}</div>}
    </section></main>
  );
}

function Dashboard({ status, busy, control }) {
  const stats = status.stats || {};
  const routeStats = status.priorityRouteStats || { enabled: 0, disabled: 0 };
  const redis = status.redis || {};
  const redisReady = redis.connected && redis.subscriberConnected !== false;
  const redisLabel = !redis.connected
    ? "Mất kết nối"
    : redis.subscriberConnected === false ? "Lệnh ổn, đồng bộ đang nối lại" : "Đã kết nối";
  return <>
    <section className={`hero-status ${status.enabled ? "running" : "stopped"}`}><span className="eyebrow">TRẠNG THÁI BOT</span><h2>{modeText(status)}</h2><p>{status.mode === "priority" ? "Chỉ phản hồi cuốc khớp tuyến ưu tiên đang bật" : "Phản hồi tất cả tin hợp lệ trong nhóm đã chọn"}</p></section>
    <section className="mode-picker panel"><h3>Chọn chế độ</h3><button className={status.mode === "all" ? "selected" : ""} disabled={busy} onClick={() => void control(status.enabled ? "start" : "stop", "all")}><strong>Nhận tất cả</strong><span>Mọi cuốc xe hợp lệ</span></button><button className={status.mode === "priority" ? "selected" : ""} disabled={busy} onClick={() => void control(status.enabled ? "start" : "stop", "priority")}><strong>Cuốc ưu tiên</strong><span>Chỉ tuyến đang bật</span></button></section>
    <section className="action-grid"><button className="start large" disabled={busy || status.enabled || Boolean(status.activeOrder)} onClick={() => void control("start")}>START<br /><small>{status.activeOrder ? "Hãy xử lý đơn hiện tại trước" : "Bắt đầu nhận đơn"}</small></button><button className="stop large" disabled={busy || !status.enabled} onClick={() => void control("stop")}>STOP<br /><small>Dừng ngay lập tức</small></button></section>
    <section className="metrics"><article><strong>{stats.sent ?? 0}</strong><span>Đã gửi phiên này</span></article><article><strong>{stats.lastLatencyMs ?? "--"}</strong><span>Tốc độ gần nhất (ms)</span></article><article><strong>{routeStats.enabled}</strong><span>Tuyến đang bật</span></article><article><strong>{routeStats.disabled}</strong><span>Tuyến đang tắt</span></article></section>
    <section className={`system-health panel ${redisReady ? "healthy" : "warning"}`}><div><strong>Redis: {redisLabel}</strong><span>{redis.connected ? `Phiên bản ${redis.version}` : "Bot đang dùng cấu hình gần nhất trong RAM"}</span></div><div><strong>Cập nhật cấu hình</strong><span>{formatTime(status.configUpdatedAt || redis.lastSyncedAt)}</span></div></section>
  </>;
}

function ReceivedOrderPage({ order, busy, onComplete }) {
  if (!order) return <section className="empty-order panel"><span className="eyebrow">ĐƠN ĐANG XỬ LÝ</span><h2>Chưa có đơn đã nhận</h2><p>Bot đang sẵn sàng nhận cuốc mới khi trạng thái START được bật.</p></section>;
  return <section className="received-order panel">
    <div className="section-heading"><div><span className="eyebrow">ĐƠN ĐÃ NHẬN</span><h2>Đang chờ điều xe</h2></div><span className="order-time">{formatTime(order.sentAt)}</span></div>
    <article className="order-detail">
      <div><span>Nội dung</span><strong>{order.originalContent || "--"}</strong></div>
      <div><span>Người gửi</span><strong>{order.senderName || order.senderId || "--"}</strong></div>
      <div><span>Nhóm Zalo</span><strong>{order.groupName || order.groupId || "--"}</strong></div>
      <div><span>Tuyến khớp</span><strong>{order.matchedRoute || "Nhận tất cả"}</strong></div>
      <div><span>Tổng thời gian</span><strong>{order.totalMs ?? order.latencyMs ?? "--"} ms</strong></div>
    </article>
    <p className="order-paused">Bot đã tự động dừng nhận đơn để bạn điều xe.</p>
    <button className="start large complete-order" disabled={busy} onClick={() => void onComplete()}>{busy ? "Đang cập nhật…" : "Đã xử lý · Bật nhận đơn lại"}</button>
  </section>;
}

function RoutesPage({ routes, visibleRoutes, routeSearch, setRouteSearch, routeFilter, setRouteFilter, savingRouteId, onAdd, onEdit, onUpdate, onDelete, onToggleAll }) {
  const allEnabled = routes.length > 0 && routes.every((route) => route.enabled);
  return <section>
    <div className="section-heading"><div><span className="eyebrow">CÀI ĐẶT</span><h2>Cuốc xe ưu tiên</h2></div><button className="primary" onClick={onAdd}>+ Thêm tuyến mới</button></div>
    <div className="route-toolbar panel"><input type="search" placeholder="Tìm điểm đi, điểm đến, giá tiền hoặc từ khóa" value={routeSearch} onChange={(event) => setRouteSearch(event.target.value)} /><select value={routeFilter} onChange={(event) => setRouteFilter(event.target.value)}><option value="all">Tất cả tuyến</option><option value="enabled">Đang bật</option><option value="disabled">Đang tắt</option></select></div>
    <label className="bulk-switch panel"><span><strong>Bật/tắt tất cả tuyến</strong><small>{routes.length} tuyến trong cấu hình</small></span><input type="checkbox" checked={allEnabled} disabled={!routes.length || savingRouteId === "all"} onChange={(event) => void onToggleAll(event.target.checked)} /></label>
    <div className="route-list">{visibleRoutes.length === 0 ? <p className="empty">Không có tuyến phù hợp.</p> : visibleRoutes.map((route) => <RouteCard key={route.id} {...{ route, savingRouteId, onEdit, onUpdate, onDelete }} />)}</div>
  </section>;
}

function RouteCard({ route, savingRouteId, onEdit, onUpdate, onDelete }) {
  const [expanded, setExpanded] = React.useState(false);
  const originCount = countListItems(route.origin);
  const destinationCount = countListItems(route.destination);
  const priceCount = (route.prices || []).length;
  const excludedCount = (route.excludedKeywords || []).length;
  return <article className={`route-card ${route.enabled ? "enabled" : "disabled"}`}>
    <div className="route-title">
      <strong>{routeDisplayTitle(route)}</strong>
      <small>{originCount} điểm đi · {destinationCount} điểm đến · {priceCount} mức giá · {excludedCount} từ khóa loại</small>
      <small>Chỉ nhận đúng chiều · Cập nhật {formatTime(route.updatedAt)}</small>
    </div>
    <div className="route-actions">
      <label><span>{route.enabled ? "Đang bật" : "Đang tắt"}</span><input type="checkbox" checked={route.enabled} disabled={savingRouteId === route.id} onChange={(event) => void onUpdate(route, { enabled: event.target.checked })} /></label>
      <button className="secondary compact" onClick={() => setExpanded((value) => !value)}>{expanded ? "Thu gọn" : "Chi tiết"}</button>
      <button className="secondary compact" onClick={() => onEdit(route)}>Sửa</button>
      <button className="danger compact" onClick={() => void onDelete(route)}>Xóa</button>
    </div>
    {expanded && <div className="route-detail">
      <div><strong>Điểm đi</strong><p>{route.origin}</p></div>
      <div><strong>Điểm đến</strong><p>{route.destination}</p></div>
      {priceCount > 0 && <div><strong>Giá nhận</strong><p>{route.prices.join(", ")}</p></div>}
      {excludedCount > 0 && <div><strong>Từ khóa bị loại</strong><p>{route.excludedKeywords.join(", ")}</p></div>}
      {route.sourceFile && <small>Nguồn: {route.sourceFile} · tải lên {formatTime(route.uploadedAt)} · {route.importRouteCount} tuyến hợp lệ</small>}
    </div>}
    {savingRouteId === route.id && <span className="saving">Đang lưu trên máy chủ…</span>}
  </article>;
}

function RouteDialog({ draft, setDraft, busy, onSave, onClose }) {
  const field = (key) => (event) => setDraft((value) => ({ ...value, [key]: event.target.value }));
  const originCount = countListItems(draft.origin);
  const destinationCount = countListItems(draft.destination);
  const overLimit = originCount > 250 || destinationCount > 250;
  return <div className="modal-backdrop"><section className="modal"><div className="section-heading"><h2>{draft.id ? "Chỉnh sửa tuyến" : "Thêm tuyến mới"}</h2><button className="icon-button" onClick={onClose}>×</button></div><label>Tên tuyến (không bắt buộc)</label><input maxLength="120" value={draft.title || ""} onChange={field("title")} placeholder="Ví dụ: Bắc Ninh → Hà Nội" /><small className="field-help">Để trống sẽ tự lấy địa chỉ đầu tiên của mỗi phía.</small><label>Điểm đi (tối đa 250 địa chỉ)</label><textarea required value={draft.origin} onChange={field("origin")} placeholder="Ví dụ: tpbn, Võ Cường, Thị Cầu, Tiên Du" /><small className={`field-help${originCount > 250 ? " limit-error" : ""}`}>{originCount}/250 địa chỉ · Ngăn cách bằng dấu phẩy hoặc xuống dòng.</small><label>Điểm đến (tối đa 250 địa chỉ)</label><textarea required value={draft.destination} onChange={field("destination")} placeholder="Ví dụ: Hà Đông, Mê Linh, Nguyễn Trãi, Mỹ Đình" /><small className={`field-help${destinationCount > 250 ? " limit-error" : ""}`}>{destinationCount}/250 địa chỉ · Có thể trùng tên với điểm đi; một lần xuất hiện không được tính cho cả hai phía.</small><label>Giá tiền (không bắt buộc)</label><textarea value={draft.prices} onChange={field("prices")} placeholder="Ví dụ: 200k; có thể nhập nhiều giá, ngăn cách bằng dấu phẩy" /><label>Từ khóa bị loại (không bắt buộc)</label><textarea value={draft.excludedKeywords} onChange={field("excludedKeywords")} placeholder="Ví dụ: chó, mèo" /><label className="switch-row"><span>Bật tuyến ngay</span><input type="checkbox" checked={draft.enabled} onChange={(event) => setDraft((value) => ({ ...value, enabled: event.target.checked }))} /></label><div className="form-actions"><button className="secondary" onClick={onClose}>Hủy</button><button className="primary" disabled={busy || overLimit || !draft.origin.trim() || !draft.destination.trim()} onClick={() => void onSave()}>{busy ? "Đang lưu…" : "Lưu trên máy chủ"}</button></div></section></div>;
}

function GroupSelector({ apiFetch, status, onStatus, onNotice }) {
  const [groups, setGroups] = React.useState([]);
  const [selectedGroupIds, setSelectedGroupIds] = React.useState([]);
  const [savedGroupIds, setSavedGroupIds] = React.useState([]);
  const [search, setSearch] = React.useState("");
  const [loading, setLoading] = React.useState(true);
  const [refreshing, setRefreshing] = React.useState(false);
  const [saving, setSaving] = React.useState(false);

  const mergeGroups = React.useCallback((availableGroups, selectedIds) => {
    const merged = new Map((availableGroups || []).map((group) => [group.id, group]));
    for (const id of selectedIds || []) {
      if (!merged.has(id)) merged.set(id, { id, name: `Nhóm ${id}` });
    }
    return [...merged.values()].sort((left, right) => left.name.localeCompare(right.name, "vi"));
  }, []);

  React.useEffect(() => {
    let cancelled = false;
    setLoading(true);
    apiFetch("/api/settings/groups")
      .then((result) => {
        if (cancelled) return;
        const selected = result.selectedGroupIds || [];
        setGroups(mergeGroups(result.groups, selected));
        setSelectedGroupIds(selected);
        setSavedGroupIds(selected);
      })
      .catch((error) => { if (!cancelled) onNotice(error.message); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [apiFetch, mergeGroups, onNotice]);

  const refreshGroups = async () => {
    setRefreshing(true);
    try {
      const result = await apiFetch("/api/settings/groups/refresh", { method: "POST" });
      setGroups(mergeGroups(result.groups, selectedGroupIds));
      onNotice(`Đã tải ${result.groups.length} nhóm từ tài khoản Zalo.`);
    } catch (error) {
      onNotice(error.message);
    } finally {
      setRefreshing(false);
    }
  };

  const saveGroups = async () => {
    setSaving(true);
    try {
      const result = await apiFetch("/api/settings/groups", {
        method: "PUT",
        body: JSON.stringify({ selectedGroupIds }),
      });
      const selected = result.selectedGroupIds || [];
      setSelectedGroupIds(selected);
      setSavedGroupIds(selected);
      setGroups((current) => mergeGroups(current, selected));
      onStatus(result.status);
      onNotice(`Đã lưu ${selected.length} nhóm được phép nhận đơn trên máy chủ.`);
    } catch (error) {
      onNotice(error.message);
    } finally {
      setSaving(false);
    }
  };

  const query = search.trim().toLocaleLowerCase("vi");
  const visibleGroups = groups.filter((group) =>
    !query || `${group.name} ${group.id}`.toLocaleLowerCase("vi").includes(query));
  const selectedSet = new Set(selectedGroupIds);
  const allVisibleSelected = visibleGroups.length > 0 && visibleGroups.every((group) => selectedSet.has(group.id));
  const dirty = [...selectedGroupIds].sort().join("\0") !== [...savedGroupIds].sort().join("\0");

  const toggleGroup = (id, checked) => {
    setSelectedGroupIds((current) => checked
      ? [...new Set([...current, id])]
      : current.filter((groupId) => groupId !== id));
  };

  const toggleVisible = (checked) => {
    const visibleIds = new Set(visibleGroups.map((group) => group.id));
    setSelectedGroupIds((current) => checked
      ? [...new Set([...current, ...visibleIds])]
      : current.filter((id) => !visibleIds.has(id)));
  };

  return <section className="settings panel group-selector">
    <div className="section-heading">
      <div><span className="eyebrow">NHÓM ZALO</span><h2>Nhóm được phép nhận đơn</h2></div>
      <span>{selectedGroupIds.length} nhóm đã chọn</span>
    </div>
    <div className="group-toolbar">
      <button className="primary" disabled={loading || refreshing || status.status !== "online"} onClick={() => void refreshGroups()}>{refreshing ? "Đang tải…" : "Tải danh sách nhóm Zalo"}</button>
      <button className="secondary" disabled={loading || saving || !dirty} onClick={() => void saveGroups()}>{saving ? "Đang lưu…" : "Lưu nhóm đã chọn"}</button>
    </div>
    <input type="search" placeholder="Tìm theo tên nhóm hoặc ID" value={search} onChange={(event) => setSearch(event.target.value)} />
    <label className="group-select-all"><span>Chọn tất cả nhóm đang hiển thị</span><input type="checkbox" checked={allVisibleSelected} disabled={visibleGroups.length === 0} onChange={(event) => toggleVisible(event.target.checked)} /></label>
    {loading
      ? <p className="muted">Đang tải cấu hình nhóm đã lưu…</p>
      : visibleGroups.length === 0
        ? <p className="empty">Bấm “Tải danh sách nhóm Zalo” để lấy các nhóm từ tài khoản đang đăng nhập.</p>
        : <div className="group-list">{visibleGroups.map((group) => <label className="group-row" key={group.id}><span><strong>{group.name}</strong><small>ID: {group.id}</small></span><input type="checkbox" checked={selectedSet.has(group.id)} onChange={(event) => toggleGroup(group.id, event.target.checked)} /></label>)}</div>}
    <p className="muted">Bỏ dấu tích ở nhóm không chất lượng rồi bấm “Lưu nhóm đã chọn”. Thay đổi được áp dụng ngay, không cần khởi động lại bot.</p>
  </section>;
}

function ZaloLogin({ status, apiUrl, token, revision, busy, onLogout }) {
  const labels = {
    online: "Đã đăng nhập",
    qr_required: "Chờ quét QR",
    connecting: "Đang kết nối",
    reconnecting: "Đang kết nối lại",
    offline: "Chưa đăng nhập",
    error: "Lỗi kết nối",
  };
  return <section className="settings panel zalo-login">
    <div className="section-heading">
      <div><span className="eyebrow">TÀI KHOẢN</span><h2>Đăng nhập Zalo</h2></div>
      <span className={`zalo-login-status ${status.status}`}>{labels[status.status] || status.status}</span>
    </div>
    {status.qrAvailable
      ? <QrCode apiUrl={apiUrl} token={token} revision={revision} />
      : status.status === "online"
        ? <p className="zalo-login-success">✓ Zalo đã đăng nhập và đang duy trì kết nối.</p>
        : <p className="muted">Máy chủ đang tạo mã QR. Mã sẽ tự xuất hiện tại đây khi sẵn sàng.</p>}
    {["online", "reconnecting", "error"].includes(status.status) && <button className="danger" disabled={busy} onClick={() => void onLogout()}>{busy ? "Đang đăng xuất…" : "Đăng xuất Zalo"}</button>}
  </section>;
}

function QrCode({ apiUrl, token, revision }) {
  const [source, setSource] = React.useState("");
  const [loadState, setLoadState] = React.useState("loading");
  const [reloadKey, setReloadKey] = React.useState(0);
  React.useEffect(() => {
    let cancelled = false;
    let objectUrl = "";
    setSource("");
    setLoadState("loading");
    const cacheKey = revision || String(Date.now());
    fetch(`${apiUrl("/api/zalo/qr")}?v=${encodeURIComponent(cacheKey)}`, {
      cache: "no-store",
      headers: { authorization: `Bearer ${token}` },
    })
      .then((response) => { if (!response.ok) throw new Error("QR chưa sẵn sàng"); return response.blob(); })
      .then((blob) => {
        if (cancelled) return;
        objectUrl = URL.createObjectURL(blob);
        setSource(objectUrl);
        setLoadState("ready");
      })
      .catch(() => { if (!cancelled) setLoadState("error"); });
    return () => {
      cancelled = true;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [apiUrl, token, revision, reloadKey]);
  return <div className="qr-card">
    <h3>Quét QR bằng ứng dụng Zalo</h3>
    {source && <img src={source} alt="Mã QR đăng nhập Zalo" />}
    {loadState === "loading" && <p className="muted">Đang tải mã QR mới…</p>}
    {loadState === "error" && <p className="error-text">Chưa tải được mã QR.</p>}
    <p className="muted">Mở Zalo trên điện thoại → Quét mã QR → Xác nhận đăng nhập.</p>
    <button className="secondary" onClick={() => setReloadKey((value) => value + 1)}>Lấy mã QR mới nhất</button>
  </div>;
}

createRoot(document.getElementById("root")).render(<App />);
