import assert from "node:assert/strict";
import http from "node:http";
import test from "node:test";
import { ThreadType } from "zca-js";
import { containsOkWord, ZaloReplyBot } from "../src/bot.js";
import { createPriorityRoute } from "../src/priority-routes.js";

const makeMessage = (overrides = {}) => ({
  threadId: "group-1",
  type: ThreadType.Group,
  isSelf: false,
  data: { msgId: "message-1", content: "Don khach tai Thu Duc" },
  ...overrides,
});

test("detects Ok as a standalone word anywhere in a message", () => {
  assert.equal(containsOkWord("Ok"), true);
  assert.equal(containsOkWord("OK nhan cuoc nhe"), true);
  assert.equal(containsOkWord("Da ok."), true);
  assert.equal(containsOkWord("booking"), false);
});

test("does not auto-reply to a message containing Ok", () => {
  let calls = 0;
  const bot = new ZaloReplyBot({
    allowedGroupIds: new Set(["group-1"]),
    replyText: "Ok",
    sessionFile: "unused",
  });
  bot.api = { sendMessage: () => { calls += 1; return Promise.resolve(); } };

  bot.onMessage(makeMessage({ data: { msgId: "message-ok", content: "OK co nguoi nhan roi" } }));
  assert.equal(calls, 0);
});

test("does not auto-reply to an empty or non-text message", () => {
  let calls = 0;
  const bot = new ZaloReplyBot({
    allowedGroupIds: new Set(["group-1"]),
    replyText: "Ok",
    sessionFile: "unused",
  });
  bot.api = { sendMessage: () => { calls += 1; return Promise.resolve(); } };

  bot.onMessage(makeMessage({ data: { msgId: "empty-message", content: "" } }));
  assert.equal(calls, 0);
});

test("creates one reusable proxy agent and forces HTTP requests through the same proxy", async () => {
  const requests = [];
  const proxyUrl = "http://user:secret@proxy.example:8080/";
  const bot = new ZaloReplyBot({
    allowedGroupIds: new Set(),
    replyText: "Ok",
    sessionFile: "unused",
    proxyUrl,
    proxyTarget: "http://proxy.example:8080",
    fetchImpl: async (url, options) => {
      requests.push({ url, options });
      return new Response("ok");
    },
  });

  const originalAgent = bot.proxyAgent;
  await bot.httpFetch("https://group.example.test/send", {
    method: "POST",
    agent: { shouldNotBeUsed: true },
    dispatcher: { shouldNotBeUsed: true },
  });
  await bot.httpFetch("https://group.example.test/send-again");

  assert.equal(bot.proxyAgent, originalAgent);
  assert.equal(bot.proxyAgent.proxy.href, proxyUrl);
  assert.equal(requests.length, 2);
  assert.equal(requests[0].options.proxy, proxyUrl);
  assert.equal(requests[1].options.proxy, proxyUrl);
  assert.equal("agent" in requests[0].options, false);
  assert.equal("dispatcher" in requests[0].options, false);
  assert.deepEqual(bot.snapshot().proxy, {
    enabled: true,
    server: "http://proxy.example:8080",
  });
});

test("applies selected and deselected groups immediately from the in-memory Set", async () => {
  let calls = 0;
  const bot = new ZaloReplyBot({
    allowedGroupIds: new Set(["group-1"]),
    replyText: "Ok",
    sessionFile: "unused",
  });
  bot.api = { sendMessage: () => { calls += 1; return Promise.resolve(); } };
  bot.setAllowedGroupIds(["group-2"]);

  bot.onMessage(makeMessage({ threadId: "group-1", data: { msgId: "deselected", content: "Cầu Giấy 200k" } }));
  bot.onMessage(makeMessage({ threadId: "group-2", data: { msgId: "selected", content: "Cầu Giấy 200k" } }));
  await new Promise((resolve) => setImmediate(resolve));

  assert.equal(calls, 1);
  assert.equal(bot.snapshot().groupsConfigured, 1);
});

test("loads large Zalo group lists in batches outside the message hot path", async () => {
  const groupIds = Array.from({ length: 45 }, (_, index) => `group-${index}`);
  const batchSizes = [];
  const bot = new ZaloReplyBot({
    allowedGroupIds: new Set(),
    replyText: "Ok",
    sessionFile: "unused",
  });
  bot.api = {
    getAllGroups: async () => ({
      gridVerMap: Object.fromEntries(groupIds.map((id) => [id, "1"])),
    }),
    getGroupInfo: async (batch) => {
      batchSizes.push(batch.length);
      return {
        gridInfoMap: Object.fromEntries(batch.map((id) => [id, { name: `Tên ${id}` }])),
      };
    },
  };

  const groups = await bot.listZaloGroups();

  assert.equal(groups.length, 45);
  assert.deepEqual(batchSizes, [20, 20, 5]);
});

test("dispatches an eligible reply synchronously without waiting for network completion", async () => {
  let calls = 0;
  let finishRequest;
  const pendingRequest = new Promise((resolve) => { finishRequest = resolve; });
  const bot = new ZaloReplyBot({
    allowedGroupIds: new Set(["group-1"]),
    replyText: "Ok",
    sessionFile: "unused",
  });
  bot.api = { sendMessage: () => { calls += 1; return pendingRequest; } };

  bot.onMessage(makeMessage());
  assert.equal(calls, 1);
  assert.equal(bot.stats.sent, 0);
  assert.equal(typeof bot.stats.lastDispatchMs, "number");

  finishRequest();
  await pendingRequest;
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(bot.stats.sent, 1);
});

test("quotes the message and mentions the sender before the reply", () => {
  let sentPayload;
  const bot = new ZaloReplyBot({
    allowedGroupIds: new Set(["group-1"]),
    replyText: "Ok",
    sessionFile: "unused",
  });
  bot.api = {
    sendMessage: (payload) => {
      sentPayload = payload;
      return Promise.resolve();
    },
  };

  bot.onMessage(makeMessage({
    data: {
      msgId: "message-with-sender",
      content: "Tpbn - cau giay 200k",
      uidFrom: "user-khanh",
      dName: "Khánh",
    },
  }));

  assert.equal(sentPayload.msg, "@Khánh Ok");
  assert.deepEqual(sentPayload.mentions, [
    { pos: 0, uid: "user-khanh", len: 6 },
  ]);
  assert.equal(sentPayload.quote.uidFrom, "user-khanh");
});

test("uses alternate sender fields when Zalo omits dName and uidFrom", () => {
  let sentPayload;
  const bot = new ZaloReplyBot({
    allowedGroupIds: new Set(["group-1"]),
    replyText: "Ok",
    sessionFile: "unused",
  });
  bot.api = { sendMessage: (payload) => { sentPayload = payload; return Promise.resolve(); } };

  bot.onMessage(makeMessage({
    data: {
      msgId: "alternate-sender",
      content: "Tpbn - cầu giấy 200k",
      fromUid: "user-khanh",
      displayName: "Khánh",
    },
  }));

  assert.equal(sentPayload.msg, "@Khánh Ok");
  assert.equal(sentPayload.mentions[0].uid, "user-khanh");
});

test("reports a synchronous send failure without throwing from the listener", () => {
  const events = [];
  const bot = new ZaloReplyBot({
    allowedGroupIds: new Set(["group-1"]),
    replyText: "Ok",
    sessionFile: "unused",
    emit: (event, payload) => events.push({ event, payload }),
  });
  bot.api = { sendMessage: () => { throw new Error("sync failure"); } };

  const originalConsoleError = console.error;
  console.error = () => {};
  try {
    assert.doesNotThrow(() => bot.onMessage(makeMessage({ data: { msgId: "sync-failure", content: "Cầu Giấy" } })));
  } finally {
    console.error = originalConsoleError;
  }
  assert.equal(events.some((item) => item.event === "ORDER_ACCEPTED"), false);
  assert.equal(events.find((item) => item.event === "ORDER_FAILED")?.payload.error, "sync failure");
});

test("emits ORDER_ACCEPTED only after the reply succeeds", async () => {
  const events = [];
  let finishRequest;
  const pendingRequest = new Promise((resolve) => { finishRequest = resolve; });
  const bot = new ZaloReplyBot({
    allowedGroupIds: new Set(["group-1"]),
    replyText: "Ok",
    sessionFile: "unused",
    emit: (event, payload) => events.push({ event, payload }),
  });
  bot.api = { sendMessage: () => pendingRequest };

  bot.onMessage(makeMessage({ data: {
    msgId: "accepted-message",
    content: "Cầu Giấy 200k",
    uidFrom: "user-khanh",
    dName: "Khánh",
    groupName: "Nhóm tài xế",
  } }));
  assert.equal(events.some((item) => item.event === "ORDER_ACCEPTED"), false);

  bot.setPriorityOnly(true);
  finishRequest();
  await pendingRequest;
  await new Promise((resolve) => setImmediate(resolve));
  const accepted = events.find((item) => item.event === "ORDER_ACCEPTED")?.payload;
  assert.equal(accepted.messageId, "accepted-message");
  assert.equal(accepted.senderId, "user-khanh");
  assert.equal(accepted.senderName, "Khánh");
  assert.equal(accepted.originalContent, "Cầu Giấy 200k");
  assert.equal(accepted.mode, "all");
  assert.equal(accepted.status, "success");
  assert.equal(bot.snapshot().enabled, false);
  assert.equal(bot.snapshot().activeOrder.eventId, accepted.eventId);
});

test("deduplicates recently accepted messages restored after a restart", () => {
  let calls = 0;
  const bot = new ZaloReplyBot({
    allowedGroupIds: new Set(["group-1"]),
    replyText: "Ok",
    sessionFile: "unused",
    recentMessages: [{ groupId: "group-1", messageId: "restored-message", status: "success" }],
  });
  bot.api = { sendMessage: () => { calls += 1; return Promise.resolve(); } };

  bot.onMessage(makeMessage({ data: { msgId: "restored-message", content: "Cầu Giấy 200k" } }));
  assert.equal(calls, 0);
});

test("deduplicates before matching priority routes", () => {
  const bot = new ZaloReplyBot({
    allowedGroupIds: new Set(["group-1"]),
    replyText: "Ok",
    sessionFile: "unused",
    priorityOnly: true,
    priorityRoutes: [createPriorityRoute({
      id: "thu-duc-quan-7",
      origin: "Thu Duc",
      destination: "Quan 7",
    })],
  });
  bot.api = { sendMessage: () => Promise.resolve() };
  const message = makeMessage({ data: { msgId: "duplicate", content: "Quan 7" } });

  bot.onMessage(message);
  bot.onMessage(message);
  assert.equal(bot.stats.prioritySkipped, 1);
});

test("starts one Zalo keep-alive request immediately without overlapping", async () => {
  let calls = 0;
  let finishRequest;
  const pendingRequest = new Promise((resolve) => { finishRequest = resolve; });
  const bot = new ZaloReplyBot({
    allowedGroupIds: new Set(),
    replyText: "Ok",
    sessionFile: "unused",
    keepAliveIntervalMs: 5000,
  });
  bot.api = { keepAlive: () => { calls += 1; return pendingRequest; } };

  bot.startKeepAlive();
  bot.startKeepAlive();
  assert.equal(calls, 1);

  bot.stopKeepAlive();
  finishRequest();
  await pendingRequest;
});

test("preconnects the group send origin once and does not call a Zalo API", () => {
  const origins = [];
  const bot = new ZaloReplyBot({
    allowedGroupIds: new Set(),
    replyText: "Ok",
    sessionFile: "unused",
    groupPreconnectIntervalMs: 60000,
    preconnect: (origin) => origins.push(origin),
  });
  bot.api = {
    zpwServiceMap: { group: ["https://group.example.test/api/group"] },
  };

  bot.startGroupPreconnect();
  bot.startGroupPreconnect();

  assert.deepEqual(origins, ["https://group.example.test"]);
  bot.stopGroupPreconnect();
});

test("preconnects the group origin immediately before dispatch", () => {
  const actions = [];
  const bot = new ZaloReplyBot({
    allowedGroupIds: new Set(["group-1"]),
    replyText: "Ok",
    sessionFile: "unused",
    preconnect: (origin) => actions.push(`preconnect:${origin}`),
  });
  bot.api = {
    zpwServiceMap: { group: ["https://group.example.test/api/group"] },
    sendMessage: () => {
      actions.push("send");
      return Promise.resolve();
    },
  };

  bot.onMessage(makeMessage({
    data: {
      msgId: "preconnect-before-send",
      content: "0 - 20p 1k ghep tpbn - my dinh 200k",
    },
  }));

  assert.deepEqual(actions, ["preconnect:https://group.example.test", "send"]);
});

test("reuses a native Bun HTTP Keep-Alive connection for sequential requests", async () => {
  const sockets = new Set();
  const server = http.createServer((_req, res) => res.end("ok"));
  server.on("connection", (socket) => sockets.add(socket));
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));

  const bot = new ZaloReplyBot({
    allowedGroupIds: new Set(),
    replyText: "Ok",
    sessionFile: "unused",
  });
  const { port } = server.address();
  const url = `http://127.0.0.1:${port}/group-message`;

  try {
    for (let index = 0; index < 8; index += 1) {
      const response = await bot.httpFetch(url, { method: "POST", body: "message=Ok" });
      await response.text();
    }

    assert.ok(sockets.size < 8);
  } finally {
    await bot.stop();
    await new Promise((resolve) => server.close(resolve));
  }
});

test("does not queue a reply behind another in-flight HTTP request", async () => {
  let firstResponse;
  let markSecondRequest;
  const secondRequestSeen = new Promise((resolve) => { markSecondRequest = resolve; });
  const server = http.createServer((_req, res) => {
    if (!firstResponse) {
      firstResponse = res;
      return;
    }
    res.end("second");
    markSecondRequest();
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  const bot = new ZaloReplyBot({ allowedGroupIds: new Set(), replyText: "Ok", sessionFile: "unused" });
  const url = `http://127.0.0.1:${server.address().port}/group-message`;

  try {
    const first = bot.httpFetch(url, { method: "POST", body: "first" });
    const second = bot.httpFetch(url, { method: "POST", body: "second" });
    await Promise.race([
      secondRequestSeen,
      new Promise((_, reject) => setTimeout(() => reject(new Error("second request was queued")), 500)),
    ]);
    firstResponse.end("first");
    await (await first).text();
    await (await second).text();
  } finally {
    await bot.stop();
    await new Promise((resolve) => server.close(resolve));
  }
});

test("does not queue replies behind a stalled Zalo keep-alive request", async () => {
  let keepAliveResponse;
  let markKeepAliveStarted;
  const keepAliveStarted = new Promise((resolve) => { markKeepAliveStarted = resolve; });
  let repliesSeen = 0;
  const server = http.createServer((req, res) => {
    if (req.url === "/keepalive") {
      keepAliveResponse = res;
      markKeepAliveStarted();
      return;
    }
    repliesSeen += 1;
    res.end("ok");
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  const bot = new ZaloReplyBot({
    allowedGroupIds: new Set(),
    replyText: "Ok",
    sessionFile: "unused",
  });
  const origin = `http://127.0.0.1:${server.address().port}`;

  try {
    const keepAliveRequest = bot.httpFetch(`${origin}/keepalive`);
    await Promise.race([
      keepAliveStarted,
      new Promise((_, reject) => setTimeout(() => reject(new Error("Keep-alive did not start")), 500)),
    ]);
    const replies = Array.from({ length: 8 }, () => bot.httpFetch(`${origin}/group-message`));
    await Promise.race([
      Promise.all(replies.map(async (request) => (await request).text())),
      new Promise((_, reject) => setTimeout(() => reject(new Error("Replies were queued")), 500)),
    ]);
    assert.equal(repliesSeen, 8);
    keepAliveResponse.end("ok");
    await (await keepAliveRequest).text();
  } finally {
    await bot.stop();
    await new Promise((resolve) => server.close(resolve));
  }
});

test("times out a stalled Zalo keep-alive request", async () => {
  const server = http.createServer(() => {});
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  const bot = new ZaloReplyBot({
    allowedGroupIds: new Set(),
    replyText: "Ok",
    sessionFile: "unused",
    keepAliveRequestTimeoutMs: 20,
  });
  const { port } = server.address();

  try {
    await assert.rejects(bot.httpFetch(`http://127.0.0.1:${port}/keepalive`), {
      name: "TimeoutError",
    });
  } finally {
    await bot.stop();
    server.closeAllConnections();
    await new Promise((resolve) => server.close(resolve));
  }
});

test("reconnects after the Zalo listener closes permanently", async () => {
  let loginCalls = 0;
  const preconnectedOrigins = [];
  const bot = new ZaloReplyBot({
    allowedGroupIds: new Set(),
    replyText: "Ok",
    sessionFile: "unused",
    keepAliveIntervalMs: 100000,
    groupPreconnectIntervalMs: 100000,
    preconnect: (origin) => preconnectedOrigins.push(origin),
    reconnectBaseDelayMs: 1,
    reconnectMaxDelayMs: 1,
  });
  bot.login = async () => {
    loginCalls += 1;
    const callbacks = {};
    return {
      zpwServiceMap: { group: [`https://group-${loginCalls}.example.test/api/group`] },
      keepAlive: () => Promise.resolve(),
      listener: {
        on: (event, callback) => { callbacks[event] = callback; },
        start: () => {
          if (loginCalls === 1) setImmediate(() => callbacks.closed());
        },
        stop: () => {},
      },
    };
  };

  await bot.start();
  await new Promise((resolve) => setTimeout(resolve, 20));
  assert.equal(loginCalls, 2);
  assert.deepEqual(preconnectedOrigins, [
    "https://group-1.example.test",
    "https://group-2.example.test",
  ]);
  await bot.stop();
});

test("retries when initial Zalo login fails", async () => {
  let loginCalls = 0;
  const bot = new ZaloReplyBot({
    allowedGroupIds: new Set(),
    replyText: "Ok",
    sessionFile: "unused",
    keepAliveIntervalMs: 100000,
    reconnectBaseDelayMs: 1,
    reconnectMaxDelayMs: 1,
  });
  bot.login = async () => {
    loginCalls += 1;
    if (loginCalls === 1) throw new Error("temporary login failure");
    return {
      keepAlive: () => Promise.resolve(),
      listener: { on: () => {}, start: () => {}, stop: () => {} },
    };
  };

  await assert.rejects(bot.start(), /temporary login failure/);
  await new Promise((resolve) => setTimeout(resolve, 20));
  assert.equal(loginCalls, 2);
  await bot.stop();
});

const mandatoryRoutes = () => [
  createPriorityRoute({ id: "bn-hn", origin: "Bắc Ninh", destination: "Hà Nội", enabled: true }),
  createPriorityRoute({ id: "bn-qn", origin: "Bắc Ninh", destination: "Quảng Ninh", enabled: false }),
  createPriorityRoute({ id: "vc-cg", origin: "Võ Cường", destination: "Cầu Giấy", enabled: true }),
];

const flushPromises = () => new Promise((resolve) => setImmediate(resolve));

test("ALL mode bypasses priority route status and accepts both mandatory trips", async () => {
  const decisions = [];
  let calls = 0;
  const bot = new ZaloReplyBot({
    allowedGroupIds: new Set(["group-1"]),
    replyText: "Ok",
    sessionFile: "unused",
    priorityRoutes: mandatoryRoutes(),
    emit: (event, payload) => { if (event === "decision") decisions.push(payload); },
  });
  bot.api = { sendMessage: () => { calls += 1; return Promise.resolve(); } };
  bot.onMessage(makeMessage({ data: { msgId: "all-1", content: "Bắc Ninh đi Hà Nội" } }));
  await flushPromises();
  bot.setControl({ enabled: true, activeOrder: null });
  bot.onMessage(makeMessage({ data: { msgId: "all-2", content: "Bắc Ninh đi Quảng Ninh" } }));
  await flushPromises();
  assert.equal(calls, 2);
  assert.deepEqual(decisions.filter((item) => item.accepted).map((item) => item.reason), ["ACCEPTED_ALL", "ACCEPTED_ALL"]);
});

test("PRIORITY mode accepts only the configured direction of an enabled route", async () => {
  const decisions = [];
  let calls = 0;
  const bot = new ZaloReplyBot({
    allowedGroupIds: new Set(["group-1"]), replyText: "Ok", sessionFile: "unused",
    priorityOnly: true, priorityRoutes: mandatoryRoutes(),
    emit: (event, payload) => { if (event === "decision") decisions.push(payload); },
  });
  bot.api = { sendMessage: () => { calls += 1; return Promise.resolve(); } };
  bot.onMessage(makeMessage({ data: { msgId: "priority-reverse", content: "Hà Nội về Bắc Ninh" } }));
  bot.onMessage(makeMessage({ data: { msgId: "priority-forward", content: "Bắc Ninh đi Hà Nội" } }));
  await flushPromises();
  assert.equal(calls, 1);
  assert.equal(decisions.filter((item) => item.reason === "ACCEPTED_PRIORITY").length, 1);
  assert.equal(decisions.find((item) => item.messageId === "priority-reverse").reason, "IGNORED_WRONG_DIRECTION");
});

test("PRIORITY mode does not send Ok for a wrong price or an excluded keyword", async () => {
  const decisions = [];
  let calls = 0;
  const bot = new ZaloReplyBot({
    allowedGroupIds: new Set(["group-1"]), replyText: "Ok", sessionFile: "unused",
    priorityOnly: true,
    priorityRoutes: [createPriorityRoute({
      id: "filtered-route",
      origin: "Bắc Ninh",
      destination: "Hà Nội",
      prices: ["200k"],
      excludedKeywords: ["chó", "mèo"],
    })],
    emit: (event, payload) => { if (event === "decision") decisions.push(payload); },
  });
  bot.api = { sendMessage: () => { calls += 1; return Promise.resolve(); } };

  bot.onMessage(makeMessage({ data: { msgId: "wrong-price", content: "Bắc Ninh - Hà Nội 150k" } }));
  bot.onMessage(makeMessage({ data: { msgId: "excluded-keyword", content: "Bắc Ninh Hà Nội 200k, chó mèo" } }));
  bot.onMessage(makeMessage({ data: { msgId: "accepted-price", content: "Bắc Ninh Hà Nội 200k" } }));
  await flushPromises();

  assert.equal(calls, 1);
  assert.equal(decisions.find((item) => item.messageId === "wrong-price").reason, "IGNORED_PRICE_MISMATCH");
  assert.equal(decisions.find((item) => item.messageId === "excluded-keyword").reason, "IGNORED_EXCLUDED_KEYWORD");
  assert.equal(decisions.find((item) => item.messageId === "accepted-price").reason, "ACCEPTED_PRIORITY");
});

test("PRIORITY mode responds immediately to enabled changes without a restart", async () => {
  const decisions = [];
  let calls = 0;
  const bot = new ZaloReplyBot({
    allowedGroupIds: new Set(["group-1"]), replyText: "Ok", sessionFile: "unused",
    priorityOnly: true, priorityRoutes: mandatoryRoutes(),
    emit: (event, payload) => { if (event === "decision") decisions.push(payload); },
  });
  bot.api = { sendMessage: () => { calls += 1; return Promise.resolve(); } };
  bot.onMessage(makeMessage({ data: { msgId: "disabled-before", content: "Bắc Ninh đi Quảng Ninh" } }));
  assert.equal(decisions.at(-1).reason, "IGNORED_ROUTE_DISABLED");
  bot.setPriorityRoutes(mandatoryRoutes().map((item) => item.id === "bn-qn" ? { ...item, enabled: true } : item));
  bot.onMessage(makeMessage({ data: { msgId: "enabled-after", content: "Bắc Ninh đi Quảng Ninh" } }));
  await flushPromises();
  assert.equal(calls, 1);
  assert.equal(decisions.at(-1).reason, "ACCEPTED_PRIORITY");
  bot.setControl({ enabled: true, activeOrder: null });
  bot.setPriorityRoutes(mandatoryRoutes());
  bot.onMessage(makeMessage({ data: { msgId: "disabled-again", content: "Bắc Ninh đi Quảng Ninh" } }));
  assert.equal(decisions.at(-1).reason, "IGNORED_ROUTE_DISABLED");
});

test("PRIORITY mode rejects an unrelated pair and a reversed route", () => {
  const decisions = [];
  const bot = new ZaloReplyBot({
    allowedGroupIds: new Set(["group-1"]), replyText: "Ok", sessionFile: "unused",
    priorityOnly: true,
    priorityRoutes: [createPriorityRoute({ id: "one-way", origin: "Bắc Ninh", destination: "Hà Nội" })],
    emit: (event, payload) => { if (event === "decision") decisions.push(payload); },
  });
  bot.api = { sendMessage: () => { throw new Error("must not send"); } };
  bot.onMessage(makeMessage({ data: { msgId: "wrong-way", content: "Hà Nội về Bắc Ninh" } }));
  bot.onMessage(makeMessage({ data: { msgId: "unrelated", content: "Hải Phòng đi Nam Định" } }));
  assert.deepEqual(decisions.map((item) => item.reason), ["IGNORED_WRONG_DIRECTION", "IGNORED_INVALID_MESSAGE"]);
});

test("a processed message is replied to and announced only once", async () => {
  const events = [];
  let calls = 0;
  const bot = new ZaloReplyBot({
    allowedGroupIds: new Set(["group-1"]), replyText: "Ok", sessionFile: "unused",
    emit: (event, payload) => events.push({ event, payload }),
  });
  bot.api = { sendMessage: () => { calls += 1; return Promise.resolve(); } };
  const message = makeMessage({ data: { msgId: "only-once", content: "Bắc Ninh đi Hà Nội" } });
  bot.onMessage(message);
  bot.onMessage(message);
  await flushPromises();
  assert.equal(calls, 1);
  assert.equal(events.filter((item) => item.event === "ORDER_ACCEPTED").length, 1);
  assert.equal(events.find((item) => item.payload.reason === "IGNORED_ORDER_IN_PROGRESS")?.payload.accepted, false);
});

test("accepts one order when the same sender posts identical content across 80 groups", async () => {
  const groupIds = Array.from({ length: 80 }, (_, index) => `group-${index + 1}`);
  const decisions = [];
  const sentTo = [];
  const bot = new ZaloReplyBot({
    allowedGroupIds: new Set(groupIds), replyText: "Ok", sessionFile: "unused",
    emit: (event, payload) => { if (event === "decision") decisions.push(payload); },
  });
  bot.api = {
    sendMessage: (_payload, threadId) => {
      sentTo.push(threadId);
      return Promise.resolve();
    },
  };

  groupIds.forEach((threadId, index) => {
    bot.onMessage(makeMessage({
      threadId,
      data: {
        msgId: `same-order-${index}`,
        uidFrom: "same-sender",
        dName: "Khánh",
        content: "Bắc Ninh đi Hà Nội 200k",
      },
    }));
  });
  await flushPromises();

  assert.deepEqual(sentTo, ["group-1"]);
  assert.equal(decisions.filter((item) => item.reason === "IGNORED_ORDER_IN_PROGRESS").length, 79);
  assert.equal(bot.stats.sent, 1);
});

test("keeps only one active order when different senders post simultaneously", async () => {
  let calls = 0;
  const bot = new ZaloReplyBot({
    allowedGroupIds: new Set(["group-1", "group-2"]), replyText: "Ok", sessionFile: "unused",
  });
  bot.api = { sendMessage: () => { calls += 1; return Promise.resolve(); } };

  bot.onMessage(makeMessage({
    threadId: "group-1",
    data: { msgId: "sender-one", uidFrom: "sender-1", content: "Bắc Ninh đi Hà Nội 200k" },
  }));
  bot.onMessage(makeMessage({
    threadId: "group-2",
    data: { msgId: "sender-two", uidFrom: "sender-2", content: "Bắc Ninh đi Hà Nội 200k" },
  }));
  await flushPromises();

  assert.equal(calls, 1);
  assert.equal(bot.stats.sent, 1);
  assert.equal(bot.snapshot().activeOrder.senderId, "sender-1");
});

test("releases the in-memory dedupe reservation when sending fails", async () => {
  let calls = 0;
  const bot = new ZaloReplyBot({
    allowedGroupIds: new Set(["group-1"]), replyText: "Ok", sessionFile: "unused",
  });
  bot.api = { sendMessage: () => {
    calls += 1;
    if (calls === 1) throw new Error("temporary failure");
    return Promise.resolve();
  } };
  const originalConsoleError = console.error;
  console.error = () => {};
  try {
    const message = makeMessage({ data: { msgId: "retry-after-failure", content: "Bắc Ninh đi Hà Nội" } });
    bot.onMessage(message);
    bot.onMessage(message);
    await flushPromises();
  } finally {
    console.error = originalConsoleError;
  }
  assert.equal(calls, 2);
  assert.equal(bot.stats.sent, 1);
});

test("a Redis outage changes infrastructure status but never changes PRIORITY to ALL", () => {
  const bot = new ZaloReplyBot({
    allowedGroupIds: new Set(), replyText: "Ok", sessionFile: "unused",
    priorityOnly: true, priorityRoutes: mandatoryRoutes(),
  });
  bot.setInfrastructureStatus({ status: "error", connected: false, error: "offline" });
  assert.equal(bot.snapshot().operationMode, "PRIORITY");
  assert.equal(bot.snapshot().redis.connected, false);
});
